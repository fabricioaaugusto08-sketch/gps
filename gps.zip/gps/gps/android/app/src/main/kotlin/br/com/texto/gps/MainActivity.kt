package br.com.texto.gps

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
