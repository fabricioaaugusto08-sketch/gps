
import 'package:flutter/material.dart';
import 'package:gps/gps.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: LocationScreen(),
  ));
}
