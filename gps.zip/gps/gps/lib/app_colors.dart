import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF4A235A);
  static const Color secondary = Color(0xFF5A4A23);

  static const Color background = Color(0xFF235A4A);
  static const Color card = Color(0xFFA569BD);

  static const Color textPrimary = Color(0xFF4A235A);
  static const Color textSecondary = Color(0xFF235A4A);

  static const Color success = Color(0xFF5A4A23);
  static const Color error = Color(0xFFA569BD);
}